import cv2
from keras.models import load_model
from PIL import Image
import numpy as np

model = load_model('BrainTumor10EpochsCategorical.h5')

image = cv2.imread('D:\Final Year Project\Brain tumor classification\pred\pred7.jpg')

img = Image.fromarray(image)

img = img.resize((64, 64))

img = np.array(img) #The resized PIL Image is converted back to a NumPy array.

input_img = np.expand_dims(img, axis=0) #function is used to add an extra dimension to the NumPy array.
#The axis=0 parameter specifies that the new dimension is added as the first dimension.

# Use predict method instead of predict_classes
predictions = model.predict(input_img)

# Extract the class with the highest probability
predicted_class = np.argmax(predictions, axis=1) #The predict method is used to obtain predictions from the model given the input image

print("Predicted Class:", predicted_class)
